package de.pcCollege;

public class DBConnection implements AutoCloseable{
    @Override
    public void close() throws Exception {

    }
}
