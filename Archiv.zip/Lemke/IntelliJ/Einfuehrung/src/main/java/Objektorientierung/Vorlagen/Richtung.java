package Objektorientierung.Vorlagen;

public enum Richtung {
    links, rechts, vor, zurueck
}
