package Objektorientierung.vererbung;

public final class Klass1 {
    protected int bla;
}
