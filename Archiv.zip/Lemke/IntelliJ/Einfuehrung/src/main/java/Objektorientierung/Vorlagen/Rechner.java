package Objektorientierung.Vorlagen;

public class Rechner {

    public int Addition(int zahl1, int zahl2) {
        return (zahl1+zahl2);
    }

    public int Subtraktion(int zahl1, int zahl2) {
        return (zahl1-zahl2);
    }

    public int Multiplikation(int zahl1, int zahl2) {
        return (zahl1*zahl2);
    }

    public float Division(int zahl1, int zahl2) {
        return (zahl1/zahl2);
    }

    public float Modulo(int zahl1, int zahl2) {
        return (zahl1%zahl2);
    }

}
