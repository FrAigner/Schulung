package Objektorientierung.vererbung;

public class Klass2 /*extends Klass1*/{
}
