package de.pcCollege.Objektorientierung2;

import java.util.Scanner;

public class ScannerTest {
    public static void main(String[] args) {
        Scanner scTest = new Scanner();
    }
}
