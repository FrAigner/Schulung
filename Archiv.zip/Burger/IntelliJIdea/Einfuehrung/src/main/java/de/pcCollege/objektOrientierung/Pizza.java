package de.pcCollege.objektOrientierung;

public class Pizza {
}
