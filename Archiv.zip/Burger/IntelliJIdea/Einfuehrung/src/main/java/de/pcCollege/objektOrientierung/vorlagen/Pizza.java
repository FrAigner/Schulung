package de.pcCollege.objektOrientierung.vorlagen;

public class Pizza {
}
