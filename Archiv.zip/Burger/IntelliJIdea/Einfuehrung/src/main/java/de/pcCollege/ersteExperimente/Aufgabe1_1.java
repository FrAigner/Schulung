package de.pcCollege.ersteExperimente;

/**
 * Aufgabenblatt 1 Aufgabe 1
 * Erstellen Sie im bereits angelegten Package eine neue Klasse mit main-Methode und darin
 * Variablen, die folgende Bedeutung haben sollen:
 * – Wie viele Menschen in Deutschland leben (Wikipedia: 83,129 Millionen)
 * – Wie viele Menschen auf der Erde leben (Wikipedia: rund 7,95 Milliarden)
 * – Ob es gerade Tag ist
 * – Wie Fußballclubs auf www.whoscored.com/Statistics bewertet werden (Rating)
 * – Wie viele Teilnehmer in Ihrem Kurs sind
 * – Mit welchem Buchstaben Ihr Nachname beginnt
 * – Den kompletten Namen einer Person
 * – Die Postleitzahl eines Orts
 * – Das Geburtsdatum einer Person
 * – Eine Telefonnummer
 * – Die Farbe eines Fahrzeugs
 * – Die Tatsache, dass ein Fahrzeug motorisiert sein kann
 * – Den Preis einer Pizza
 * Verwenden Sie bei der Anzahl Menschen in Deutschland/auf der Erde natürliche Zahlen.
 * Weisen Sie jeder Variablen mit „=“ einen passenden Wert zu. Erstellen Sie Ausgabebefehle
 * für jede Variable und führen das Programm aus
 */
public class Aufgabe1_1 {
    public static void main(String[] args) {

    }
}
