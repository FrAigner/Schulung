package de.pcCollege.objektOrientierung.schnittstellen;

public class Rechteck implements Geometrieberechnung{
    /**
     * Berechnet Umfang von Rechteck mit Eingabeparametern
     * @param z1 Breite
     * @param z2 Länge
     * @return Umfang
     */
    @Override
    public double berechneUmfang(double z1, double z2) {
        return 0;
    }

    /**
     * @description Das ist die Beschreibung
     * @param z1
     * @param z2
     * @return
     */
    @Override
    public double berechneFlaeche(double z1, double z2) {
        return 0;
    }
}
