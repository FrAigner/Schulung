package de.pcCollege.ersteExperimente;

import java.util.Scanner;

public class ErsteKlasse {
    public static void main(String[] args) {
        /**
         * Dies sind die ersten Schritte
         */
//        char z = 'A';
//        // Ausgabe
//        System.out.println("Bitte geben Sie Ihren Namen ein");
//        // Eingabe
//        Scanner eingabe = new Scanner(System.in);
//        String namensText = eingabe.next();
//        System.out.printf("Guten Morgen, Herr/Frau %s", namensText);
//        String [] wochentage = {"Montag", "Dienstag", "Mittwoch", "Donnerstag", "Freitag", "Samstag", "Sonntag"};
//        System.out.println(wochentage);
//        try {
//            System.out.println(wochentage[7]);
//        }
//        catch (Exception e)
//        {
//            System.out.println(e.getMessage());
//            System.err.println(e.getMessage());
//            e.printStackTrace();
//        }
//        finally {
//            System.out.println("*********** Test ***********");
//        }
//
//        int [] alter = {25, 33, 47, 28, 36};
        System.out.printf("pi hat den Wert %.15f", Math.PI);
    }
}
