package de.pcCollege.ersteExperimente;

import java.util.Scanner;

public class Waehrungsrechner {
    public static void main(String[] args) {
        Scanner eingabe = new Scanner(System.in);
//        System.out.println("Bitte geben Sie den Euro-Betrag ein");
//        double euro = eingabe.nextDouble();
//        System.out.println("Bitte geben Sie den Wechselkurs ein");
//        double wKurs = eingabe.nextDouble();
        String test = "ÄÖÜ äöü Was ich nicht weiß macht mich nicht heiß";
        System.out.println(test);
//        System.out.printf("Für %.2f ergeben sich beim Wechselkurs %.4f: %.2f Dollar", euro, wKurs, euro*wKurs);

    }
}
