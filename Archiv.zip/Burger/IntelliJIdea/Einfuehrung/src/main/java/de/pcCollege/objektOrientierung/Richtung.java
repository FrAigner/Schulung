package de.pcCollege.objektOrientierung;

public enum Richtung {
    links, rechts, vor, zurueck
}
