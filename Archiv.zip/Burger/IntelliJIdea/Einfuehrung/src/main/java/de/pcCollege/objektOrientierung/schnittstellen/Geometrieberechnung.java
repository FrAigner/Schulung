package de.pcCollege.objektOrientierung.schnittstellen;

public interface Geometrieberechnung {
    public double berechneUmfang(double z1, double z2);
    public double berechneFlaeche(double z1, double z2);
}
