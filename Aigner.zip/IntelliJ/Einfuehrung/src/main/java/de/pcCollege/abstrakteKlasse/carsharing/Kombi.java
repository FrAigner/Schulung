package de.pcCollege.abstrakteKlasse.carsharing;

public class Kombi {
}
