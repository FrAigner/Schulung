package de.pcCollege.objektorientierung;

public enum Richtung {
    links,rechts,vor,zurueck
}
