package de.pcCollege.ersteExperimente;

public class ersteAufgabe {
    public static void main(String[] args) {
        //        - Wie viele Menschen in Deutschland leben (Wikipedia: 83,129 Millionen)
        long menschenInDeutschland = 83129000L;
//        – Wie viele Menschen auf der Erde leben (Wikipedia: rund 7,95 Milliarden)
        long menschenAufDerErde = 7950000000L;
//        – Ob es gerade Tag ist
        Boolean tag = true;
//        – Wie Fußballclubs auf www.whoscored.com/Statistics bewertet werden (Rating)
        int fussballclubsRating = 5;
//        – Wie viele Teilnehmer in Ihrem Kurs sind
        int teilnehmer = 456;
//        – Mit welchem Buchstaben Ihr Nachname beginnt
        char nachnameBuchstabe = 'H';
//        – Den kompletten Namen einer Person
        String nameDerPerson = "Jens";
//        – Die Postleitzahl eines Orts
        String plz = "12345";
//        – Das Geburtsdatum einer Person
        String gebDatum = "01.01.1980";
//        – Eine Telefonnummer
        String telefonnummer = "0123456789";
//        – Die Farbe eines Fahrzeugs
        String kfzFarbe = "Blau";
//        – Die Tatsache, dass ein Fahrzeug motorisiert sein kann
        Boolean motor = true;
//        – Den Preis einer Pizza
        double preis = 3.95;
    }
}
