package de.pcCollege.Vorlage;

public class Rechner {

    public double Addition(double addition1, double addition2 ) {
        return addition1 + addition2;
    };

    public double Subtraktion(double subtraktion1, double subtraktion2) {
        return subtraktion1 - subtraktion2;
    };

    public double Multiplikation(double multiplikation1, double multiplikation2) {
        return multiplikation1 * multiplikation2;
    };

    public double Modulo(double modulo1, double modulo2) {
        return modulo1 % modulo2;
    };
}
