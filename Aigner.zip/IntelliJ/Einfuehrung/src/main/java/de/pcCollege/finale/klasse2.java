package de.pcCollege.finale;

//public class klasse2 extends klasse1{
//}
